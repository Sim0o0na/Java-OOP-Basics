/**
 * Created by Simona Simeonova on 21-Feb-17.
 */
public class BankAccount {
    private Integer id;
    private double balance;

    public void setId(Integer id){
        this.id = id;
    }

    public double getBalance(){
        return this.balance;
    }

    public void deposit(double n){
        if (n<0){
            throw new IllegalArgumentException("Should be positive");
        }
        this.balance+=n;
    }
    public void withdraw(double n){
        if (n>this.balance){
            throw new IllegalArgumentException("Should be positive");
        }
        this.balance-=n;
    }

    @Override
    public String toString(){
        return "ID" + this.id;
    }
}
