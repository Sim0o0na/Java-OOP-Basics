import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

/**
 * Created by Simona Simeonova on 21-Feb-17.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
        HashMap<Integer, BankAccount> accounts = new HashMap<>();

        while(true){
            String[] command = scan.readLine().split(" ");
            if(command[0].equals("End")){
                break;
            }
            if(command[0].equals("Create")){
                Integer id = Integer.parseInt(command[1]);
                create(accounts, id);
            }
            if(command[0].equals("Deposit")){
                Integer id = Integer.parseInt(command[1]);
                deposit(accounts,id,Double.parseDouble(command[2]));
            }
            if(command[0].equals("Withdraw")){
                Integer id = Integer.parseInt(command[1]);
                Double amount = Double.parseDouble(command[2]);
                withdraw(accounts, id, amount);
            }
            if(command[0].equals("Print")){
                Integer id = Integer.parseInt(command[1]);
                print(accounts,id);
            }
        }
    }
    private static void create(HashMap<Integer, BankAccount> accounts, Integer key){
        if(accounts.containsKey(key)){
            System.out.println("Account already exists");
        }else{
            BankAccount account = new BankAccount();
            account.setId(key);
            accounts.put(key, account);
        }
    }

    private static void deposit(HashMap<Integer, BankAccount> accounts, Integer key, Double amount){
        if(!accounts.containsKey(key)){
            System.out.println("Account does not exist");
        }else {
            accounts.get(key).deposit(amount);
        }
    }

    private static void withdraw(HashMap<Integer, BankAccount> accounts, Integer key, Double amount){
        if(!accounts.containsKey(key)){
            System.out.println("Account does not exist");
        }else{
            try{
                accounts.get(key).withdraw(amount);
            }catch(IllegalArgumentException iae){
                System.out.println("Insufficient balance");
            }
        }
    }

    private static void print(HashMap<Integer, BankAccount> accounts, Integer key) {
        if(!accounts.containsKey(key)){
            System.out.println("Account does not exist");
        }else{
            System.out.printf("Account %s, balance %.2f \n", accounts.get(key),
                    accounts.get(key).getBalance());
        }
    }
}

