package multilevel_inheritance;

/**
 * Created by Sim0o on 2/28/2017.
 */
public class Main {
    public static void main(String[] args) {
        Puppy puppy = new Puppy();
        puppy.eat();
        puppy.bark();
        puppy.weep();
    }
}
