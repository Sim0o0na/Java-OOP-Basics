package stack_of_strings;

/**
 * Created by Sim0o on 3/1/2017.
 */
public class Main {
    public static void main(String[] args) {

    }
}
