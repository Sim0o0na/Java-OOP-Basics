package single_inheritance;

/**
 * Created by Sim0o on 2/28/2017.
 */
public class Dog extends Animal {
    public void bark(){
        System.out.println("barking...");
    }
}
