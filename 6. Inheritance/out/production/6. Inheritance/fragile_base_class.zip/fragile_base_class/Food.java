package fragile_base_class;

/**
 * Created by Sim0o on 2/28/2017.
 */
public class Food {

}
