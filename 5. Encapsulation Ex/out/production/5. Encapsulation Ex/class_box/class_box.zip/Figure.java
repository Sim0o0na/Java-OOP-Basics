package class_box;

/**
 * Created by Simona Simeonova on 25-Feb-17.
 */
public class Figure {
    public double getLenght() {
        return lenght;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    private double lenght;
    private double width;
    private double height;

    public Figure(double len, double w, double h){
        this.lenght = len;
        this.width = w;
        this.height = h;
    }

    public double surfaceArea(){
        double surface = (2*this.getLenght()*this.getWidth()) +
                (2*this.getLenght()*this.getHeight()) + (2*this.getWidth()*this.getHeight());
        return surface;
    }

    public double lateralArea(){
        double lateral = (2*this.getLenght()*this.getHeight()) + (2*this.getWidth()*this.getHeight());
        return lateral;
    }

    public double volume(){
        double volume = this.getLenght()*this.getWidth()*this.getHeight();
        return volume;
    }
}
