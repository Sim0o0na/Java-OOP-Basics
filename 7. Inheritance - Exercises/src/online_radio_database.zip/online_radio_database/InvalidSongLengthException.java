package online_radio_database;

/**
 * Created by Sim0o on 3/2/2017.
 */
public class InvalidSongLengthException extends InvalidSongException {
    public InvalidSongLengthException(String s){
        super(s);
    }
}
