/**
 * Created by Simona Simeonova on 23-Feb-17.
 */
public class Person {
    private String firstName;
    private String lastName;
    private Integer age;

    public Person(String fName, String lName, Integer age){
        this.firstName = fName;
        this.lastName = lName;
        this.age = age;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public Integer getAge() {
        return this.age;
    }

    @Override
    public String toString() {
        return this.getFirstName() +" " + this.getLastName() + " is a " + this.getAge()+ " years old.";
    }
}
