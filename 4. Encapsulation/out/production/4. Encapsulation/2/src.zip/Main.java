import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Simona Simeonova on 23-Feb-17.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());
        List<Person> people = new ArrayList<>();
        while(n-->0){
            String[] line = reader.readLine().split(" ");
            people.add(new Person(line[0], line[1], Integer.valueOf(line[2]), Double.parseDouble(line[3])));
        }
        int bonus = Integer.parseInt(reader.readLine());
        for (Person person : people) {
            person.increaseSalary((double)bonus);
            System.out.println(person.toString());
        }

    }
}
