/**
 * Created by Simona Simeonova on 23-Feb-17.
 */
public class Person {
    private String firstName;
    private String lastName;
    private Integer age;
    private double salary;

    public Person(String fName, String lName, Integer age, double salary){
        this.firstName = fName;
        this.lastName = lName;
        this.age = age;
        this.salary = salary;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public Integer getAge() {
        return this.age;
    }

    public double getSalary() {return this.salary;}

    public double increaseSalary(Double n){
        if(this.getAge()<30){
            this.salary +=n/200 * this.getSalary();
        }else{
            this.salary +=this.getSalary()*(n/100);
        }
        return this.salary+n;
    }

    @Override
    public String toString() {
        return this.getFirstName() +" " + this.getLastName() + " get " + this.getSalary()+ " leva";
    }
}
