package wild_farm;

/**
 * Created by Sim0o on 3/7/2017.
 */
public abstract class Mammal extends Animal {
    private String livingRegion;

    public String getLivingRegion() {
        return livingRegion;
    }

    public void setLivingRegion(String livingRegion) {
        this.livingRegion = livingRegion;
    }
}
