package wild_farm;

/**
 * Created by Sim0o on 3/7/2017.
 */
public class Food {
    private int quantity;

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
