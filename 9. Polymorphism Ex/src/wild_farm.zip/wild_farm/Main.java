package wild_farm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by Sim0ona on 3/7/2017.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String command = reader.readLine();
        while (!command.equals("End")) {
            String[] animalInfo = command.split("\\s+");
            String[] foodInfo = reader.readLine().split("\\s+");
            Food food = null;
            Animal animal = null;
            if(foodInfo[0].equals("Vegetable")){
                food = new Vegetable(Integer.parseInt(foodInfo[1]));
            }
            else if(foodInfo[0].equals("Meat")){
                food = new Meat(Integer.parseInt(foodInfo[1]));
            }
            try {
                if (animalInfo[0].equals("Cat")) {
                    animal = new Cat(animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3], animalInfo[4]);
                    animal.makeSound();
                    animal.eatFood(food);
                }
                if (animalInfo[0].equals("Tiger")) {
                    animal = new Tiger(animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3]);
                    animal.makeSound();
                    animal.eatFood(food);
                }
                if (animalInfo[0].equals("Zebra")) {
                    animal = new Zebra(animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3]);
                    animal.makeSound();
                    animal.eatFood(food);
                }
                if (animalInfo[0].equals("Mouse")) {
                    animal = new Mouse(animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3]);
                    animal.makeSound();
                    animal.eatFood(food);
                }
            }catch (IllegalArgumentException e){
                System.out.println(e.getMessage());
            }
            System.out.println(animal.toString());
            command = reader.readLine();
        }
    }
}
