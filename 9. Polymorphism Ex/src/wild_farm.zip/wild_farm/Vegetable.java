package wild_farm;

import sun.awt.FontDescriptor;

/**
 * Created by Sim0o on 3/7/2017.
 */
public class Vegetable extends Food{
    public Vegetable(int quantity){
        this.setQuantity(quantity);
    }
}
