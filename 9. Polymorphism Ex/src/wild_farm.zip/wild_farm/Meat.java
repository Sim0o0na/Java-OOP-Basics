package wild_farm;

/**
 * Created by Sim0o on 3/7/2017.
 */
public class Meat extends Food {
    public Meat(int quantity){
        this.setQuantity(quantity);
    }
}
